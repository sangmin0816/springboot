package webSocket.chat.controller;

import lombok.Data;

@Data
public class RoomForm {
    private String name;
}
